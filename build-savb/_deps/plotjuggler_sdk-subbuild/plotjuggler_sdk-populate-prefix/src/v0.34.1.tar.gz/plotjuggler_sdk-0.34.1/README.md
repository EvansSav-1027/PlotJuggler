# PlotJuggler SDK

[![Linux CI](https://github.com/PlotJuggler/plotjuggler_sdk/actions/workflows/linux-ci.yml/badge.svg)](https://github.com/PlotJuggler/plotjuggler_sdk/actions/workflows/linux-ci.yml)
[![Windows CI](https://github.com/PlotJuggler/plotjuggler_sdk/actions/workflows/windows-ci.yml/badge.svg)](https://github.com/PlotJuggler/plotjuggler_sdk/actions/workflows/windows-ci.yml)

C++20 foundation libraries for [PlotJuggler](https://github.com/facontidavide/PlotJuggler).

Start with [Existing SDK utilities](docs/sdk-utilities.md) before writing helpers.
Source providers also follow [the provider contract](docs/provider-guide.md).
Both guides ship under `share/plotjuggler_sdk/docs/` in the installed package.

## Modules

| Module | Description | Dependencies | License |
|--------|-------------|--------------|---------|
| **pj_base** | Vocabulary types: `Timestamp`, `DatasetId`, `TopicId`, type trees, `Expected<T>`, `Span<T>` | None | Apache-2.0 |
| **pj_source** | Provider descriptors, origins, artifact cache, jobs, limits, presentation, completion and Stop; link `plotjuggler_sdk::source` | pj_base, nlohmann/json | Apache-2.0 |
| **pj_plugins** | C-ABI plugin protocol (DataSource, MessageParser, Dialog, Toolbox families), C++ SDK base classes, plugin discovery, host-side loaders, and config helpers | pj_base, nlohmann/json | Apache-2.0 |
| **cmake/** | Plugin-authoring CMake helpers shipped with `plugin_sdk`: `pj_configure_plugin()` (symbol isolation, export allowlist + gate, manifest validation/sidecar/embed), `pj_embed_file()`, `pj_harden_plugin_exports()`, `pj_add_parser_module()`, `pj_add_sdk_test_fixture()` — see `examples/sdk_consumer` | — | Apache-2.0 |

## Getting Started

**Prerequisites:** C++20 compiler (GCC 11+), [Conan 2](https://conan.io/), CMake 3.22+.

### LLVM tooling (clang-format, clangd, clang-tidy)

```bash
wget https://apt.llvm.org/llvm.sh
chmod +x llvm.sh
sudo ./llvm.sh 22
sudo apt install clangd-22 clang-format-22 clang-tidy-22
```

### Build and test

```bash
git clone <this repo>
cd plotjuggler_sdk

./build.sh              # RelWithDebInfo (build/)
./build.sh --debug      # Debug + ASAN (build/debug_asan)
./test.sh               # runs tests in all discovered build dirs
git ls-files -z '*.cpp' | xargs -0 clang-tidy-22 -p build   # clang-tidy
```

## Project Layout

```
pj_base/                   Vocabulary, builtin codecs and sdk/source/ provider support
pj_plugins/                C-ABI plugin protocol, SDK, host loaders
cmake/                     Installed CMake helpers for plugin authors (PjPlugin.cmake, PjParserModule.cmake, PjSdkTestFixtures.cmake)
examples/sdk_consumer/     find_package() consumer exercising the helpers (built by the release + conda checks)
docs/                      Project-wide design guides
```

## License

PlotJuggler SDK is **Apache-2.0** ([LICENSE-APACHE](LICENSE-APACHE)); each
source file carries an authoritative `SPDX-License-Identifier` header. You may
build **proprietary plugins and applications** on the SDK without restriction;
Apache-2.0 also grants an explicit patent license.

The columnar storage engine (formerly the MPL-2.0 `pj_datastore` module) has
moved to the PlotJuggler application repo; plugins load through a stable C ABI
and never link it. See [LICENSE](LICENSE) for the full mapping.
