/**
 * @file toolbox_plugin_base.hpp
 * @brief C++ SDK for implementing Toolbox plugins (protocol v4).
 *
 * All trampolines are noexcept at the ABI boundary.
 */
// Copyright 2026 Davide Faconti
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstring>
#include <exception>
#include <string>
#include <string_view>
#include <utility>

#include "pj_base/expected.hpp"
#include "pj_base/plugin_abi_export.hpp"
#include "pj_base/sdk/data_source_host_views.hpp"  // ParserIngestHostView, errorToString
#include "pj_base/sdk/plugin_data_api.hpp"
#include "pj_base/sdk/service_registry.hpp"
#include "pj_base/sdk/service_traits.hpp"
#include "pj_base/toolbox_protocol.h"

namespace PJ {

enum class ToolboxMessageLevel : uint32_t {
  kInfo = PJ_TOOLBOX_MESSAGE_INFO,
  kWarning = PJ_TOOLBOX_MESSAGE_WARNING,
  kError = PJ_TOOLBOX_MESSAGE_ERROR,
};

constexpr uint64_t kToolboxCapabilityHasDialog = PJ_TOOLBOX_CAPABILITY_HAS_DIALOG;
constexpr uint64_t kToolboxCapabilityNonModalDialog = PJ_TOOLBOX_CAPABILITY_NON_MODAL_DIALOG;

/// Type-safe view over the toolbox runtime host vtable.
class ToolboxRuntimeHostView {
 public:
  ToolboxRuntimeHostView() = default;
  explicit ToolboxRuntimeHostView(PJ_toolbox_runtime_host_t host) : host_(host) {}

  [[nodiscard]] bool valid() const {
    return host_.ctx != nullptr && host_.vtable != nullptr;
  }

  void reportMessage(ToolboxMessageLevel level, std::string_view message) const noexcept {
    if (valid() && host_.vtable->report_message != nullptr) {
      host_.vtable->report_message(
          host_.ctx, static_cast<PJ_toolbox_message_level_t>(level), sdk::toAbiString(message));
    }
  }

  void notifyDataChanged() const {
    if (valid() && host_.vtable->notify_data_changed != nullptr) {
      host_.vtable->notify_data_changed(host_.ctx);
    }
  }

  /// Create (or fetch) the parser-ingest context for a toolbox-created data
  /// source (pass ToolboxHostView::createDataSource's handle `.id`). Returns
  /// the shared delegated-ingest view: ensureParserBinding() once per topic,
  /// pushMessage() per record. Drive the returned view from a single worker
  /// thread; unlike reportMessage/notifyDataChanged, parser ingest is not
  /// GUI-marshalled.
  [[nodiscard]] Expected<ParserIngestHostView> createParserIngest(uint32_t data_source_id) const;

  /// Flush + destroy the context. Idempotent. The view returned by
  /// createParserIngest must not be used afterwards.
  [[nodiscard]] Status releaseParserIngest(uint32_t data_source_id) const;

  /// Abort the provisional ingest WITHOUT committing (discard_parser_ingest
  /// tail slot): staged source records are dropped and any capture is never
  /// published — the rollback twin of releaseParserIngest. Quiesce every user
  /// of the ingest view first, and serialize release/discard per dataset id.
  /// Idempotent for an unknown id. An older host without the slot returns an
  /// error; releaseParserIngest is NOT a substitute for abort — it is normal
  /// finalization, and after a COMPLETED terminal it can authorize the very
  /// capture the caller meant to discard. Fall back to it only once
  /// publication has been vetoed and the owning transaction aborted by other
  /// means; slot absence alone establishes neither.
  [[nodiscard]] Status discardParserIngest(uint32_t data_source_id) const;

  /// Generic alias over the same context as createParserIngest: the canonical
  /// dataset-scoped ingest lifecycle for BOTH delegated parsing and direct
  /// toolbox writes (progress/stop + optional parser access). Same threading
  /// rule: drive the returned view from a single worker thread.
  [[nodiscard]] Expected<DatasetIngestHostView> createDatasetIngest(uint32_t data_source_id) const;

  /// Flush + destroy the context (same slot as releaseParserIngest).
  /// Idempotent. The view returned by createDatasetIngest must not be used
  /// afterwards.
  [[nodiscard]] Status releaseDatasetIngest(uint32_t data_source_id) const;

  [[nodiscard]] const PJ_toolbox_runtime_host_t& raw() const {
    return host_;
  }

 private:
  /// Shared validity/tail-slot-gate/ABI-call/error-mapping body for
  /// createParserIngest and createDatasetIngest — both wrap the same
  /// create_parser_ingest slot in different view types.
  [[nodiscard]] Expected<PJ_data_source_runtime_host_t> acquireParserIngestContext(uint32_t data_source_id) const;

  PJ_toolbox_runtime_host_t host_{};
};

}  // namespace PJ

namespace PJ::sdk {

/// Service trait for the toolbox runtime host. Defined here (rather than in
/// service_traits.hpp) because it depends on `ToolboxRuntimeHostView` which
/// lives in this header.
struct ToolboxRuntimeHostService {
  static constexpr const char* kName = "pj.toolbox_runtime.v1";
  static constexpr uint32_t kMinVersion = 1;
  using Raw = PJ_toolbox_runtime_host_t;
  using Vtable = PJ_toolbox_runtime_host_vtable_t;
  using View = ::PJ::ToolboxRuntimeHostView;
};

}  // namespace PJ::sdk

namespace PJ {

/**
 * Base class for Toolbox plugins (protocol v4).
 */
class ToolboxPluginBase {
 public:
  virtual ~ToolboxPluginBase() = default;

  virtual uint64_t capabilities() const = 0;

  /// Acquire host-provided services.
  ///
  /// Default implementation pulls:
  ///   - "pj.toolbox_write.v1"       → ToolboxHost          (mandatory)
  ///   - "pj.toolbox_runtime.v1"     → RuntimeHost          (mandatory)
  ///   - "pj.colormap.v1"            → ColorMap             (optional)
  ///   - "pj.toolbox_object_read.v1" → ObjectReadHost       (optional)
  ///
  /// Override to acquire additional services or relax defaults.
  virtual Status bind(sdk::ServiceRegistry services);

  virtual std::string saveConfig() const {
    return "{}";
  }

  virtual Status loadConfig(std::string_view config_json) {
    (void)config_json;
    return okStatus();
  }

  /// Return a typed borrowed reference to this toolbox's embedded dialog.
  /// Default returns `{nullptr, nullptr}` (no dialog).
  virtual PJ_borrowed_dialog_t getDialog() {
    return PJ_borrowed_dialog_t{nullptr, nullptr};
  }

  /// React to data appended to the datastore. Default is no-op.
  virtual void onDataChanged() {}

  /// Return a pointer to a static plugin-exposed extension for @p id, or
  /// nullptr if unknown. Default returns nullptr.
  virtual const void* pluginExtension(std::string_view id) {
    (void)id;
    return nullptr;
  }

  template <typename CreateFn>
  static const PJ_toolbox_vtable_t* vtableWithCreate(CreateFn create_fn, const char* manifest) {
    PJ_ASSERT(manifest != nullptr && manifest[0] == '{', "manifest must be a JSON object");
    PJ_ASSERT(std::strstr(manifest, "\"id\"") != nullptr, "manifest must contain an \"id\" key");
    PJ_ASSERT(std::strstr(manifest, "\"name\"") != nullptr, "manifest must contain a \"name\" key");
    PJ_ASSERT(std::strstr(manifest, "\"version\"") != nullptr, "manifest must contain a \"version\" key");
    static const PJ_toolbox_vtable_t vt = {
        PJ_TOOLBOX_PLUGIN_PROTOCOL_VERSION,
        sizeof(PJ_toolbox_vtable_t),
        create_fn,
        trampoline_destroy,
        manifest,
        trampoline_capabilities,
        trampoline_bind,
        trampoline_save_config,
        trampoline_load_config,
        trampoline_get_dialog,
        trampoline_on_data_changed,
        trampoline_get_plugin_extension,
    };
    return &vt;
  }

 protected:
  [[nodiscard]] sdk::ServiceRegistry services() const {
    return service_registry_;
  }

  [[nodiscard]] const sdk::ToolboxHostView& toolboxHost() const {
    return toolbox_host_view_;
  }

  [[nodiscard]] const ToolboxRuntimeHostView& runtimeHost() const {
    return runtime_host_view_;
  }

  [[nodiscard]] const sdk::ColorMapRegistryView& colorMapRegistry() const {
    return colormap_view_;
  }

  /// Optional — returns nullptr when the host does not register
  /// `pj.toolbox_object_read.v1`. Transformer-style toolboxes check this
  /// before touching ObjectStore; scalar-only toolboxes never call it.
  [[nodiscard]] const sdk::ToolboxObjectReadHostView* objectReadHost() const {
    return object_read_host_view_.valid() ? &object_read_host_view_ : nullptr;
  }

  [[nodiscard]] bool toolboxHostBound() const {
    return toolbox_host_view_.valid();
  }
  [[nodiscard]] bool runtimeHostBound() const {
    return runtime_host_view_.valid();
  }
  [[nodiscard]] bool colorMapRegistryBound() const {
    return colormap_view_.valid();
  }

 private:
  sdk::ServiceRegistry service_registry_{};
  sdk::ToolboxHostView toolbox_host_view_{PJ_toolbox_host_t{}};
  ToolboxRuntimeHostView runtime_host_view_{};
  sdk::ColorMapRegistryView colormap_view_{};
  sdk::ToolboxObjectReadHostView object_read_host_view_{};
  std::string config_buf_;

  static void storeError(PJ_error_t* out_error, int32_t code, std::string_view domain, std::string_view message) {
    sdk::fillError(out_error, code, domain, message);
  }

  static void trampoline_destroy(void* ctx) noexcept;
  static uint64_t trampoline_capabilities(void* ctx) noexcept;
  static bool trampoline_bind(void* ctx, PJ_service_registry_t registry, PJ_error_t* out_error) noexcept;
  static bool trampoline_save_config(void* ctx, PJ_string_view_t* out_json, PJ_error_t* out_error) noexcept;
  static bool trampoline_load_config(void* ctx, PJ_string_view_t config_json, PJ_error_t* out_error) noexcept;
  static PJ_borrowed_dialog_t trampoline_get_dialog(void* ctx) noexcept;
  static void trampoline_on_data_changed(void* ctx) noexcept;
  static const void* trampoline_get_plugin_extension(void* ctx, PJ_string_view_t id) noexcept;
};

}  // namespace PJ

#define PJ_TOOLBOX_PLUGIN(ClassName, manifest)                                               \
  PJ_EXPORT_PLUGIN_ABI_VERSION(PJ_TOOLBOX_EXPORT)                                            \
  extern "C" PJ_TOOLBOX_EXPORT const PJ_toolbox_vtable_t* PJ_get_toolbox_vtable() noexcept { \
    static const PJ_toolbox_vtable_t* vt = PJ::ToolboxPluginBase::vtableWithCreate(          \
        []() noexcept -> void* {                                                             \
          try {                                                                              \
            return new ClassName();                                                          \
          } catch (...) {                                                                    \
            return nullptr;                                                                  \
          }                                                                                  \
        },                                                                                   \
        manifest);                                                                           \
    return vt;                                                                               \
  }

// Variant for namespaced plugin classes. SymbolName must be an unqualified
// identifier and is used only to form the unique static getter name.
#define PJ_TOOLBOX_PLUGIN_NAMED(ClassName, SymbolName, manifest) PJ_TOOLBOX_PLUGIN(ClassName, manifest)

// --- Static-link variant (WASM / no dlopen) ---  see data_source_plugin_base.hpp
#ifdef PJ_STATIC_PLUGINS
#undef PJ_TOOLBOX_PLUGIN
#undef PJ_TOOLBOX_PLUGIN_NAMED
#define PJ_TOOLBOX_PLUGIN_NAMED(ClassName, SymbolName, manifest)                    \
  const PJ_toolbox_vtable_t* pj_static_get_toolbox_vtable_##SymbolName() noexcept { \
    static const PJ_toolbox_vtable_t* vt = PJ::ToolboxPluginBase::vtableWithCreate( \
        []() noexcept -> void* {                                                    \
          try {                                                                     \
            return new ClassName();                                                 \
          } catch (...) {                                                           \
            return nullptr;                                                         \
          }                                                                         \
        },                                                                          \
        manifest);                                                                  \
    return vt;                                                                      \
  }
#define PJ_TOOLBOX_PLUGIN(ClassName, manifest) PJ_TOOLBOX_PLUGIN_NAMED(ClassName, ClassName, manifest)
#endif
