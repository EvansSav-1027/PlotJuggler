/**
 * @file abi_layout_sentinels_test.cpp
 * @brief Compile-time sentinels that pin the plugin C ABI layout.
 *
 * Every assertion here is a static_assert. A failure at compile time means
 * a struct defined in the ABI-visible headers has shifted in a way that
 * would silently break binary compatibility with existing plugins.
 *
 * Maintenance rule:
 *   - Sizes and alignments are allowed to GROW at the tail (new slots
 *     appended). In that case, update the `sizeof` and MIN-size assertions
 *     deliberately — the intent is "I appended a slot, the ABI is still
 *     backward-compatible because struct_size gates the read."
 *   - Offsets of existing fields MUST NOT CHANGE. A failing `offsetof`
 *     assertion means someone reordered fields, which is always an ABI
 *     break.
 *   - MIN-size constants (PJ_*_MIN_VTABLE_SIZE) MUST NEVER INCREASE
 *     within a major version. They are pinned at v4.0 release and are
 *     the floor that forward compatibility relies on within the current
 *     major series.
 *
 * Pinning target: x86-64 System V (Linux/macOS on Intel/AMD). For other
 * ABIs (ARM64, MSVC), either confirm identical layout during initial
 * port or add target-specific guards here.
 */
// Copyright 2026 Davide Faconti
// SPDX-License-Identifier: Apache-2.0

#include <cstddef>
#include <cstdint>
#include <string_view>

#include "pj_base/data_source_protocol.h"
#include "pj_base/descriptor_import_protocol.h"
#include "pj_base/message_parser_protocol.h"
#include "pj_base/parser_functional_protocol.h"
#include "pj_base/parser_module_abi.h"
#include "pj_base/parser_route_claims_protocol.h"
#include "pj_base/plugin_data_api.h"
#include "pj_base/toolbox_protocol.h"

// --- Word-size guard ---------------------------------------------------------
// The entire ABI is pinned to 64-bit. A 32-bit regression would shift every
// pointer-aligned field and silently invalidate every other assertion below.
static_assert(sizeof(void*) == 8, "v4 ABI pinned to 64-bit targets");

// --- Enum size guards --------------------------------------------------------
// Each ABI enum carries a `..._FORCE_INT32 = 0x7FFFFFFF` enumerator that pins
// its width to a stable 4 bytes even under `-fshort-enums` in a third-party
// plugin build — the enumerator is what travels into the plugin's compiler;
// these static_asserts only verify the pinning holds in this build too.
static_assert(sizeof(PJ_primitive_type_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_data_source_state_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_data_source_message_level_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_message_box_type_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_message_box_buttons_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_toolbox_message_level_t) == 4, "enum layout pinned");
static_assert(sizeof(PJ_parser_diagnostic_level_t) == 4, "parser diagnostic enum layout pinned");

// --- PJ_error_t (ABI-FROZEN) -------------------------------------------------
static_assert(sizeof(PJ_error_t) == 304, "PJ_error_t size pinned at v4.0 release");
static_assert(alignof(PJ_error_t) == 8, "PJ_error_t alignment pinned");
static_assert(offsetof(PJ_error_t, code) == 0, "PJ_error_t layout pinned");
static_assert(offsetof(PJ_error_t, domain) == 4, "PJ_error_t layout pinned");
static_assert(offsetof(PJ_error_t, message) == 36, "PJ_error_t layout pinned");
static_assert(offsetof(PJ_error_t, extended) == 264, "PJ_error_t layout pinned");
static_assert(offsetof(PJ_error_t, extended_kind) == 272, "PJ_error_t layout pinned");

// --- PJ_playback_state_t (ABI-FROZEN) -----------------------------------------
// bool + 7 padding bytes + 4 doubles: the alignment-hole shape this test exists
// to pin. Growth goes through a get_state_v2 tail slot, never through this struct.
static_assert(sizeof(PJ_playback_state_t) == 40, "PJ_playback_state_t size pinned at introduction (0.28.0)");
static_assert(alignof(PJ_playback_state_t) == 8, "PJ_playback_state_t alignment pinned");
static_assert(offsetof(PJ_playback_state_t, is_playing) == 0, "PJ_playback_state_t layout pinned");
static_assert(offsetof(PJ_playback_state_t, current_time_s) == 8, "PJ_playback_state_t layout pinned");
static_assert(offsetof(PJ_playback_state_t, range_min_s) == 16, "PJ_playback_state_t layout pinned");
static_assert(offsetof(PJ_playback_state_t, range_max_s) == 24, "PJ_playback_state_t layout pinned");
static_assert(offsetof(PJ_playback_state_t, playback_rate) == 32, "PJ_playback_state_t layout pinned");

// Playback vtable: source selection extends the existing topic-based prefix.
static_assert(offsetof(PJ_playback_host_vtable_t, to_display_time) == 48, "topic conversion slot stays fixed");
static_assert(offsetof(PJ_playback_host_vtable_t, to_display_time_for_source) == 56, "source conversion is appended");
static_assert(sizeof(PJ_playback_host_vtable_t) == 64, "playback vtable size in 0.28.0");

// --- Service registry (fat pointer types) ------------------------------------
static_assert(sizeof(PJ_service_t) == 16, "PJ_service_t fat pointer pinned");
static_assert(sizeof(PJ_service_registry_t) == 16, "PJ_service_registry_t fat pointer pinned");
static_assert(sizeof(PJ_borrowed_dialog_t) == 16, "PJ_borrowed_dialog_t fat pointer pinned");

// --- DataSource vtable (ABI-APPENDABLE within v4) ----------------------------
// Offsets of v4.0 slots: PINNED. sizeof and MIN_VTABLE_SIZE are allowed to
// grow at the tail via future appends within the current major series.
static_assert(offsetof(PJ_data_source_vtable_t, protocol_version) == 0, "v4 prefix pinned");
static_assert(offsetof(PJ_data_source_vtable_t, struct_size) == 4, "v4 prefix pinned");
static_assert(offsetof(PJ_data_source_vtable_t, bind) == 40, "v4 bind slot pinned");
static_assert(offsetof(PJ_data_source_vtable_t, start) == 64, "v4 lifecycle slot pinned");
static_assert(offsetof(PJ_data_source_vtable_t, get_dialog) == 112, "v4 get_dialog slot pinned");
static_assert(offsetof(PJ_data_source_vtable_t, get_plugin_extension) == 120, "v4 last baseline slot pinned");
static_assert(sizeof(PJ_data_source_vtable_t) == 128, "DataSource vtable size (update deliberately on append)");
static_assert(PJ_DATA_SOURCE_MIN_VTABLE_SIZE == 128, "MIN vtable size is pinned at v4.0 — NEVER INCREASE");
static_assert(
    PJ_DATA_SOURCE_MIN_VTABLE_SIZE <= sizeof(PJ_data_source_vtable_t),
    "MIN must never exceed current — host would reject its own vtable");

// --- MessageParser vtable (ABI-APPENDABLE within v4) -------------------------
static_assert(offsetof(PJ_message_parser_vtable_t, protocol_version) == 0, "v4 prefix pinned");
static_assert(offsetof(PJ_message_parser_vtable_t, struct_size) == 4, "v4 prefix pinned");
static_assert(offsetof(PJ_message_parser_vtable_t, bind) == 32, "v4 bind slot pinned");
static_assert(offsetof(PJ_message_parser_vtable_t, parse) == 64, "v4 parse slot pinned");
static_assert(offsetof(PJ_message_parser_vtable_t, get_plugin_extension) == 72, "v4 last baseline slot pinned");
// 80 baseline (v4.0) + 1 tail slot × 8 bytes = 88.
static_assert(sizeof(PJ_message_parser_vtable_t) == 88, "MessageParser vtable size (update deliberately on append)");
static_assert(PJ_MESSAGE_PARSER_MIN_VTABLE_SIZE == 80, "MIN vtable size is pinned at v4.0 — NEVER INCREASE");
static_assert(PJ_MESSAGE_PARSER_MIN_VTABLE_SIZE <= sizeof(PJ_message_parser_vtable_t), "MIN must never exceed current");

// --- Toolbox vtable (ABI-APPENDABLE within v4) -------------------------------
static_assert(offsetof(PJ_toolbox_vtable_t, protocol_version) == 0, "v4 prefix pinned");
static_assert(offsetof(PJ_toolbox_vtable_t, struct_size) == 4, "v4 prefix pinned");
static_assert(offsetof(PJ_toolbox_vtable_t, bind) == 40, "v4 bind slot pinned");
static_assert(offsetof(PJ_toolbox_vtable_t, on_data_changed) == 72, "v4 on_data_changed slot pinned");
static_assert(offsetof(PJ_toolbox_vtable_t, get_plugin_extension) == 80, "v4 last baseline slot pinned");
static_assert(sizeof(PJ_toolbox_vtable_t) == 88, "Toolbox vtable size (update deliberately on append)");
static_assert(PJ_TOOLBOX_MIN_VTABLE_SIZE == 88, "MIN vtable size is pinned at v4.0 — NEVER INCREASE");
static_assert(PJ_TOOLBOX_MIN_VTABLE_SIZE <= sizeof(PJ_toolbox_vtable_t), "MIN must never exceed current");

// --- Canonical-object pipeline structs ---------------------------------------
// Public ABI types crossing the boundary for the v4 builtin-object pipeline.
// Sizes and offsets are pinned; any change is a deliberate ABI revision.
static_assert(sizeof(PJ_builtin_object_type_t) == 4, "enum layout pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_NONE == 0, "None type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_IMAGE == 1, "Image type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_POINTCLOUD == 3, "PointCloud type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_DEPTH_IMAGE == 4, "DepthImage type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_IMAGE_ANNOTATIONS == 5, "ImageAnnotations type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_FRAME_TRANSFORMS == 6, "FrameTransforms type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_OCCUPANCY_GRID == 7, "OccupancyGrid type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_COMPRESSED_POINTCLOUD == 8, "CompressedPointCloud type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_MESH3D == 9, "Mesh3D type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_VIDEO_FRAME == 10, "VideoFrame type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_SCENE_ENTITIES == 11, "SceneEntities type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_ROBOT_DESCRIPTION == 13, "RobotDescription type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_CAMERA_INFO == 14, "CameraInfo type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_OCCUPANCY_GRID_UPDATE == 15, "OccupancyGridUpdate type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_LOG == 16, "Log type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_POSES_IN_FRAME == 17, "PosesInFrame type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_VOXEL_GRID == 18, "VoxelGrid type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_PLOT_MARKERS == 19, "PlotMarkers type id pinned");
static_assert(PJ_BUILTIN_OBJECT_TYPE_GRID_MAP == 20, "GridMap type id pinned");
static_assert(sizeof(PJ_schema_classification_t) == 4, "PJ_schema_classification_t layout pinned");
static_assert(offsetof(PJ_schema_classification_t, object_type) == 0, "object_type at offset 0");
static_assert(offsetof(PJ_schema_classification_t, reserved) == 2, "reserved at offset 2");
static_assert(sizeof(PJ_builtin_object_splice_field_v1_t) == 8, "builtin splice table entry size pinned");
static_assert(
    offsetof(PJ_builtin_object_splice_field_v1_t, object_type) == 0, "builtin splice object_type offset pinned");
static_assert(offsetof(PJ_builtin_object_splice_field_v1_t, reserved) == 2, "builtin splice reserved offset pinned");
static_assert(
    offsetof(PJ_builtin_object_splice_field_v1_t, field_number) == 4, "builtin splice field_number offset pinned");

// Parser functional extension v1. These caller-owned sink tables are the
// only values crossing the new parser result boundary; freeze their first
// published layout independently of the C++ convenience wrappers.
#if INTPTR_MAX == INT64_MAX
static_assert(offsetof(PJ_parser_scalar_sink_v1_t, struct_size) == 0, "scalar sink prefix pinned");
static_assert(offsetof(PJ_parser_scalar_sink_v1_t, ctx) == 8, "scalar sink context pinned");
static_assert(offsetof(PJ_parser_scalar_sink_v1_t, accept_record) == 16, "scalar sink callback pinned");
static_assert(sizeof(PJ_parser_scalar_sink_v1_t) == 24, "scalar sink size pinned");
static_assert(offsetof(PJ_parser_object_sink_v1_t, struct_size) == 0, "object sink prefix pinned");
static_assert(offsetof(PJ_parser_object_sink_v1_t, ctx) == 8, "object sink context pinned");
static_assert(offsetof(PJ_parser_object_sink_v1_t, accept_object) == 16, "object sink callback pinned");
static_assert(sizeof(PJ_parser_object_sink_v1_t) == 24, "object sink size pinned");
static_assert(offsetof(PJ_parser_functional_v1_t, struct_size) == 0, "functional extension prefix pinned");
static_assert(offsetof(PJ_parser_functional_v1_t, parse_scalars) == 8, "functional scalar slot pinned");
static_assert(offsetof(PJ_parser_functional_v1_t, parse_object) == 16, "functional object slot pinned");
static_assert(sizeof(PJ_parser_functional_v1_t) == 24, "functional extension size pinned");

static_assert(offsetof(PJ_parser_object_sink_v2_t, struct_size) == 0, "v2 object sink prefix pinned");
static_assert(offsetof(PJ_parser_object_sink_v2_t, ctx) == 8, "v2 object sink context pinned");
static_assert(offsetof(PJ_parser_object_sink_v2_t, accept_object) == 16, "v2 full object callback pinned");
static_assert(offsetof(PJ_parser_object_sink_v2_t, accept_object_spliced) == 24, "v2 splice callback pinned");
static_assert(sizeof(PJ_parser_object_sink_v2_t) == 32, "v2 object sink size pinned");
static_assert(PJ_PARSER_OBJECT_SINK_V2_MIN_SIZE == 32, "v2 object sink minimum size pinned");
static_assert(offsetof(PJ_parser_functional_v2_t, struct_size) == 0, "functional v2 prefix pinned");
static_assert(offsetof(PJ_parser_functional_v2_t, parse_scalars) == 8, "functional v2 scalar slot pinned");
static_assert(offsetof(PJ_parser_functional_v2_t, parse_object) == 16, "functional v2 object slot pinned");
static_assert(sizeof(PJ_parser_functional_v2_t) == 24, "functional v2 size pinned");
static_assert(PJ_PARSER_FUNCTIONAL_V2_MIN_SIZE == 24, "functional v2 minimum size pinned");

static_assert(sizeof(PJ_route_classification_v1_t) == 8, "route classification v1 size pinned");
static_assert(offsetof(PJ_route_classification_v1_t, route_flags) == 0, "route flags offset pinned");
static_assert(offsetof(PJ_route_classification_v1_t, match) == 2, "route match offset pinned");
static_assert(offsetof(PJ_route_classification_v1_t, status) == 4, "route status offset pinned");
static_assert(offsetof(PJ_route_classification_v1_t, object_type) == 6, "route object type offset pinned");
static_assert(offsetof(PJ_parser_route_claims_v1_t, struct_size) == 0, "route claims prefix pinned");
static_assert(offsetof(PJ_parser_route_claims_v1_t, classify_routes) == 8, "route claims callback pinned");
static_assert(sizeof(PJ_parser_route_claims_v1_t) == 16, "route claims extension size pinned");
static_assert(PJ_PARSER_ROUTE_CLAIMS_V1_MIN_SIZE == 16, "route claims minimum size pinned");
#endif

static_assert(PJ_PARSER_MODULE_ABI_VERSION == 1, "parser module ABI version pinned");
static_assert(PJ_MODULE_OK == 0, "parser module OK result pinned");
static_assert(PJ_MODULE_DECLINE == 1, "parser module DECLINE result pinned");
static_assert(PJ_MODULE_ERR_GENERIC == -1, "parser module generic error pinned");
static_assert(PJ_MODULE_ERR_BAD_TOKEN == -2, "parser module bad-token error pinned");
static_assert(PJ_MODULE_ERR_MALFORMED_INPUT == -3, "parser module malformed-input error pinned");
static_assert(PJ_MODULE_ERR_BAD_CLAIM_INDEX == -4, "parser module bad-claim-index error pinned");
static_assert(PJ_MODULE_ERR_ALLOCATION_FAILURE == -5, "parser module allocation error pinned");
static_assert(PJ_MODULE_CREATION_ERROR_TOKEN == 0, "parser module creation-error token pinned");
static_assert(PJ_MODULE_ERROR_BUFFER_SIZE == 512, "parser module error buffer size pinned");
static_assert(std::string_view(PJ_MODULE_ABI_EXPORT_NAME) == "pj_module_abi", "parser module ABI export name pinned");
static_assert(
    std::string_view(PJ_MODULE_CREATE_EXPORT_NAME) == "pj_module_create", "parser module create export name pinned");
static_assert(
    std::string_view(PJ_MODULE_DESTROY_EXPORT_NAME) == "pj_module_destroy", "parser module destroy export name pinned");
static_assert(
    std::string_view(PJ_MODULE_BIND_EXPORT_NAME) == "pj_module_bind", "parser module bind export name pinned");
static_assert(
    std::string_view(PJ_MODULE_PARSE_EXPORT_NAME) == "pj_module_parse", "parser module parse export name pinned");
static_assert(
    std::string_view(PJ_MODULE_LAST_ERROR_EXPORT_NAME) == "pj_module_last_error",
    "parser module last-error export name pinned");
static_assert(
    std::string_view(PJ_MODULE_ALLOC_EXPORT_NAME) == "pj_module_alloc", "parser module alloc export name pinned");
static_assert(
    std::string_view(PJ_MODULE_FREE_EXPORT_NAME) == "pj_module_free", "parser module free export name pinned");
static_assert(
    std::string_view(PJ_MODULE_MANIFEST_ADDR_EXPORT_NAME) == "pj_module_manifest_addr",
    "native parser module manifest-address export name pinned");
static_assert(
    std::string_view(PJ_MODULE_MANIFEST_LEN_EXPORT_NAME) == "pj_module_manifest_len",
    "native parser module manifest-length export name pinned");
static_assert(
    std::string_view(PJ_PARSER_MODULE_MANIFEST_SECTION_NAME) == "pj_parser_module_manifest",
    "wasm parser module manifest section name pinned");
static_assert(sizeof(PJ_module_parse_fn_t) == sizeof(void*), "parser module function pointer width pinned");

static_assert(sizeof(PJ_payload_anchor_t) == 16, "PJ_payload_anchor_t pinned (ctx + release fn ptr)");
static_assert(offsetof(PJ_payload_anchor_t, ctx) == 0, "ctx at offset 0");
static_assert(offsetof(PJ_payload_anchor_t, release) == 8, "release at offset 8");

static_assert(sizeof(PJ_payload_t) == 32, "PJ_payload_t pinned (data + size + anchor)");
static_assert(offsetof(PJ_payload_t, data) == 0, "data at offset 0");
static_assert(offsetof(PJ_payload_t, size) == 8, "size at offset 8");
static_assert(offsetof(PJ_payload_t, anchor) == 16, "anchor at offset 16");

static_assert(
    sizeof(PJ_message_data_fetcher_t) == 24, "PJ_message_data_fetcher_t pinned (ctx + fetchMessageData + release)");
static_assert(offsetof(PJ_message_data_fetcher_t, ctx) == 0, "ctx at offset 0");
static_assert(offsetof(PJ_message_data_fetcher_t, fetchMessageData) == 8, "fetchMessageData at offset 8");
static_assert(offsetof(PJ_message_data_fetcher_t, release) == 16, "release at offset 16");

// --- DataSource runtime host vtable (ABI-APPENDABLE within v4) ---------------
// The vtable the host exposes to plugins under "pj.runtime.v1". Offsets of
// existing slots are pinned; size grows deliberately as tail slots append.
static_assert(offsetof(PJ_data_source_runtime_host_vtable_t, protocol_version) == 0, "v1 prefix pinned");
static_assert(offsetof(PJ_data_source_runtime_host_vtable_t, struct_size) == 4, "v1 prefix pinned");
static_assert(offsetof(PJ_data_source_runtime_host_vtable_t, report_message) == 8, "v1 first slot pinned");
static_assert(
    offsetof(PJ_data_source_runtime_host_vtable_t, list_available_encodings) == 80,
    "list_available_encodings slot pinned");
static_assert(offsetof(PJ_data_source_runtime_host_vtable_t, push_message) == 88, "push_message tail slot pinned");
static_assert(
    offsetof(PJ_data_source_runtime_host_vtable_t, notify_available_topics) == 96,
    "notify_available_topics tail slot pinned");
static_assert(
    offsetof(PJ_data_source_runtime_host_vtable_t, attach_source_record) == 104,
    "attach_source_record tail slot pinned");
static_assert(sizeof(PJ_ingest_outcome_t) == 4, "ingest outcome enum width pinned (force-int32)");
static_assert(offsetof(PJ_ingest_completion_t, struct_size) == 0, "completion struct_size pinned");
static_assert(offsetof(PJ_ingest_completion_t, outcome) == 4, "completion outcome pinned");
static_assert(offsetof(PJ_ingest_completion_t, flags) == 8, "completion flags pinned");
static_assert(offsetof(PJ_ingest_completion_t, requested_topics) == 16, "completion topic list pinned");
static_assert(offsetof(PJ_ingest_completion_t, requested_topic_count) == 24, "completion topic count pinned");
static_assert(sizeof(PJ_ingest_completion_t) == 32, "completion struct size (update deliberately on append)");
static_assert(
    offsetof(PJ_data_source_runtime_host_vtable_t, complete_ingest) == 112, "complete_ingest tail slot pinned");
static_assert(
    offsetof(PJ_data_source_runtime_host_vtable_t, set_dataset_metadata) == 120,
    "set_dataset_metadata tail slot pinned");
static_assert(
    sizeof(PJ_data_source_runtime_host_vtable_t) == 128, "Runtime host vtable size (update deliberately on append)");

// --- Write-host vtables (ABI-APPENDABLE within v4) --------------------------
static_assert(offsetof(PJ_source_write_host_vtable_t, abi_version) == 0, "source write host prefix pinned");
static_assert(offsetof(PJ_source_write_host_vtable_t, struct_size) == 4, "source write host prefix pinned");
static_assert(offsetof(PJ_source_write_host_vtable_t, append_bound_record) == 32, "source write host baseline pinned");
static_assert(offsetof(PJ_source_write_host_vtable_t, append_arrow_stream) == 40, "source write host bulk slot pinned");
static_assert(sizeof(PJ_source_write_host_vtable_t) == 48, "Source write host size");

static_assert(offsetof(PJ_parser_write_host_vtable_t, abi_version) == 0, "parser write host prefix pinned");
static_assert(offsetof(PJ_parser_write_host_vtable_t, struct_size) == 4, "parser write host prefix pinned");
static_assert(offsetof(PJ_parser_write_host_vtable_t, append_bound_record) == 24, "parser write host baseline pinned");
static_assert(
    offsetof(PJ_parser_write_host_vtable_t, append_arrow_stream) == 32, "parser write host bulk tail slot pinned");
static_assert(sizeof(PJ_parser_write_host_vtable_t) == 40, "Parser write host size updated deliberately on append");
static_assert(PJ_PARSER_WRITE_HOST_MIN_VTABLE_SIZE == 32, "Parser write host min size remains v4.0 baseline");
static_assert(
    PJ_PARSER_WRITE_HOST_MIN_VTABLE_SIZE <= sizeof(PJ_parser_write_host_vtable_t), "MIN must never exceed current");

// --- Parser runtime diagnostics service (ABI-APPENDABLE) --------------------
static_assert(offsetof(PJ_parser_runtime_host_vtable_t, protocol_version) == 0, "parser runtime prefix pinned");
static_assert(offsetof(PJ_parser_runtime_host_vtable_t, struct_size) == 4, "parser runtime prefix pinned");
static_assert(offsetof(PJ_parser_runtime_host_vtable_t, report_diagnostic) == 8, "parser runtime slot pinned");
static_assert(sizeof(PJ_parser_runtime_host_vtable_t) == 16, "Parser runtime host size");
static_assert(sizeof(PJ_parser_runtime_host_t) == 16, "Parser runtime host fat pointer pinned");

static_assert(offsetof(PJ_toolbox_host_vtable_t, abi_version) == 0, "toolbox host prefix pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, struct_size) == 4, "toolbox host prefix pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, append_bound_record) == 40, "toolbox host baseline pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, append_arrow_stream) == 48, "toolbox host bulk slot pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, read_series_arrow) == 64, "toolbox host read slot pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, register_object_topic) == 72, "toolbox host object-topic slot pinned");
static_assert(offsetof(PJ_toolbox_host_vtable_t, push_owned_object) == 80, "toolbox host object-push tail slot pinned");
static_assert(
    offsetof(PJ_toolbox_host_vtable_t, register_object_topic_on_dataset) == 88,
    "toolbox host object-topic-on-dataset tail slot pinned");
static_assert(
    offsetof(PJ_toolbox_host_vtable_t, set_object_topic_retention) == 96,
    "toolbox host object-retention tail slot pinned");
static_assert(sizeof(PJ_toolbox_host_vtable_t) == 104, "Toolbox host size (update deliberately on append)");

// --- Toolbox runtime host vtable (ABI-APPENDABLE within v4) ------------------
// The vtable the host exposes to plugins under "pj.toolbox_runtime.v1".
// Offsets of existing slots are pinned; size grows deliberately as tail slots append.
static_assert(offsetof(PJ_toolbox_runtime_host_vtable_t, protocol_version) == 0, "toolbox runtime v1 prefix pinned");
static_assert(offsetof(PJ_toolbox_runtime_host_vtable_t, struct_size) == 4, "toolbox runtime v1 prefix pinned");
static_assert(offsetof(PJ_toolbox_runtime_host_vtable_t, report_message) == 8, "toolbox runtime first slot pinned");
static_assert(
    offsetof(PJ_toolbox_runtime_host_vtable_t, notify_data_changed) == 16, "toolbox runtime second slot pinned");
static_assert(
    offsetof(PJ_toolbox_runtime_host_vtable_t, create_parser_ingest) == 24,
    "toolbox runtime parser-ingest slot pinned");
static_assert(
    offsetof(PJ_toolbox_runtime_host_vtable_t, release_parser_ingest) == 32,
    "toolbox runtime parser-ingest release slot pinned");
static_assert(
    offsetof(PJ_toolbox_runtime_host_vtable_t, discard_parser_ingest) == 40,
    "toolbox runtime parser-ingest discard slot pinned");
static_assert(
    sizeof(PJ_toolbox_runtime_host_vtable_t) == 48, "Toolbox runtime host size (update deliberately on append)");

// --- ABI version symbol ------------------------------------------------------
static_assert(PJ_ABI_VERSION == 5, "v5 ABI version");

// ---- descriptor_import_protocol.h (new in 0.20.0) --------------------------
// First ABI pins for extension/service structs. Same maintenance rule as
// above: tails may grow (update sizeof deliberately); existing offsets never
// move.

static_assert(sizeof(PJ_descriptor_trust_t) == 4, "PJ_descriptor_trust_t enum layout pinned");
static_assert(sizeof(PJ_descriptor_import_outcome_t) == 4, "PJ_descriptor_import_outcome_t enum layout pinned");
static_assert(sizeof(PJ_descriptor_import_start_flags_t) == 8, "PJ_descriptor_import_start_flags_t width pinned");

static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, struct_size) == 0,
    "PJ_descriptor_query_result_v1_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, reserved0) == 4,
    "PJ_descriptor_query_result_v1_t.reserved0 offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, trust) == 8, "PJ_descriptor_query_result_v1_t.trust offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, is_materialized) == 12,
    "PJ_descriptor_query_result_v1_t.is_materialized offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, source_identity) == 16,
    "PJ_descriptor_query_result_v1_t.source_identity offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, local_path_utf8) == 32,
    "PJ_descriptor_query_result_v1_t.local_path_utf8 offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, message) == 48, "PJ_descriptor_query_result_v1_t.message offset frozen");
static_assert(
    offsetof(PJ_descriptor_query_result_v1_t, estimated_bytes) == 64,
    "PJ_descriptor_query_result_v1_t.estimated_bytes offset frozen");
static_assert(
    sizeof(PJ_descriptor_query_result_v1_t) == 72,
    "PJ_descriptor_query_result_v1_t size (update deliberately on append)");

static_assert(
    offsetof(PJ_descriptor_import_start_request_v1_t, struct_size) == 0,
    "PJ_descriptor_import_start_request_v1_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_start_request_v1_t, reserved0) == 4,
    "PJ_descriptor_import_start_request_v1_t.reserved0 offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_start_request_v1_t, descriptor_json) == 8,
    "PJ_descriptor_import_start_request_v1_t.descriptor_json offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_start_request_v1_t, flags) == 24,
    "PJ_descriptor_import_start_request_v1_t.flags offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_start_request_v1_t, max_transfer_bytes) == 32,
    "PJ_descriptor_import_start_request_v1_t.max_transfer_bytes offset frozen");
static_assert(
    sizeof(PJ_descriptor_import_start_request_v1_t) == 40,
    "PJ_descriptor_import_start_request_v1_t size (update deliberately on append)");

static_assert(
    offsetof(PJ_descriptor_import_callbacks_v1_t, struct_size) == 0,
    "PJ_descriptor_import_callbacks_v1_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_callbacks_v1_t, reserved0) == 4,
    "PJ_descriptor_import_callbacks_v1_t.reserved0 offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_callbacks_v1_t, on_dataset) == 8,
    "PJ_descriptor_import_callbacks_v1_t.on_dataset offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_callbacks_v1_t, on_terminal) == 16,
    "PJ_descriptor_import_callbacks_v1_t.on_terminal offset frozen");
static_assert(
    sizeof(PJ_descriptor_import_callbacks_v1_t) == 24,
    "PJ_descriptor_import_callbacks_v1_t size (update deliberately on append)");

static_assert(
    offsetof(PJ_joinable_job_vtable_t, struct_size) == 0, "PJ_joinable_job_vtable_t.struct_size offset frozen");
static_assert(offsetof(PJ_joinable_job_vtable_t, reserved0) == 4, "PJ_joinable_job_vtable_t.reserved0 offset frozen");
static_assert(offsetof(PJ_joinable_job_vtable_t, cancel) == 8, "PJ_joinable_job_vtable_t.cancel offset frozen");
static_assert(offsetof(PJ_joinable_job_vtable_t, join) == 16, "PJ_joinable_job_vtable_t.join offset frozen");
static_assert(offsetof(PJ_joinable_job_vtable_t, destroy) == 24, "PJ_joinable_job_vtable_t.destroy offset frozen");
static_assert(sizeof(PJ_joinable_job_vtable_t) == 32, "PJ_joinable_job_vtable_t size (update deliberately on append)");
static_assert(sizeof(PJ_joinable_job_t) == 16, "PJ_joinable_job_t fat pointer pinned");

static_assert(
    offsetof(PJ_descriptor_import_provider_v1_t, struct_size) == 0,
    "PJ_descriptor_import_provider_v1_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_provider_v1_t, reserved0) == 4,
    "PJ_descriptor_import_provider_v1_t.reserved0 offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_provider_v1_t, query_descriptor) == 8,
    "PJ_descriptor_import_provider_v1_t.query_descriptor offset frozen");
static_assert(
    offsetof(PJ_descriptor_import_provider_v1_t, start_import) == 16,
    "PJ_descriptor_import_provider_v1_t.start_import offset frozen");
static_assert(
    sizeof(PJ_descriptor_import_provider_v1_t) == 24,
    "PJ_descriptor_import_provider_v1_t size (update deliberately on append)");

static_assert(
    offsetof(PJ_source_promotion_request_v1_t, struct_size) == 0,
    "PJ_source_promotion_request_v1_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, dataset) == 4, "PJ_source_promotion_request_v1_t.dataset offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, source_identity) == 8,
    "PJ_source_promotion_request_v1_t.source_identity offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, local_path_utf8) == 24,
    "PJ_source_promotion_request_v1_t.local_path_utf8 offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, loader_plugin_id) == 40,
    "PJ_source_promotion_request_v1_t.loader_plugin_id offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, loader_config_json) == 56,
    "PJ_source_promotion_request_v1_t.loader_config_json offset frozen");
static_assert(
    offsetof(PJ_source_promotion_request_v1_t, descriptor_json) == 72,
    "PJ_source_promotion_request_v1_t.descriptor_json offset frozen");
static_assert(
    sizeof(PJ_source_promotion_request_v1_t) == 88,
    "PJ_source_promotion_request_v1_t size (update deliberately on append)");

static_assert(
    offsetof(PJ_source_promotion_host_vtable_t, protocol_version) == 0,
    "PJ_source_promotion_host_vtable_t.protocol_version offset frozen");
static_assert(
    offsetof(PJ_source_promotion_host_vtable_t, struct_size) == 4,
    "PJ_source_promotion_host_vtable_t.struct_size offset frozen");
static_assert(
    offsetof(PJ_source_promotion_host_vtable_t, promote_to_file_source) == 8,
    "PJ_source_promotion_host_vtable_t.promote_to_file_source offset frozen");
static_assert(
    sizeof(PJ_source_promotion_host_vtable_t) == 16,
    "PJ_source_promotion_host_vtable_t size (update deliberately on append)");
static_assert(sizeof(PJ_source_promotion_host_t) == 16, "PJ_source_promotion_host_t fat pointer pinned");

// This translation unit has no runtime behavior; the above are all
// compile-time assertions. Linking only confirms the TU compiled.
extern "C" void pj_abi_layout_sentinels_touch() {}
