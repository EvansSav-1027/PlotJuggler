#pragma once
// Copyright 2026 Davide Faconti
// SPDX-License-Identifier: Apache-2.0

/**
 * @file plugin_catalog.hpp
 * @brief Plugin discovery from each DSO's embedded manifest.
 *
 * Plugin DSOs export a family-specific vtable whose `manifest_json` field is
 * the source of truth for local plugin metadata. Dialogs compiled against the
 * original v4.0 protocol may lack that tail slot; the scanner falls back to
 * their legacy `create()` + `get_manifest()` path. The scanner walks plugin
 * files, inspects those exports, parses the embedded manifest, and reports both
 * valid descriptors and diagnostics for candidates that could not be used.
 */

#include <cstdint>
#include <filesystem>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

#include "pj_base/expected.hpp"

namespace PJ {

/// Plugin family inferred from the DSO's exported protocol vtable.
enum class PluginFamily : uint32_t {
  kUnknown = 0,
  kDataSource = 1,
  kMessageParser = 2,
  kToolbox = 3,
  kDialog = 4,
};

/// Plugin descriptor parsed from a DSO's embedded manifest.
/// All fields except `dso_path`, `family`, `id`, `name`, and `version` are
/// optional and may be empty.
struct PluginDescriptor {
  std::filesystem::path dso_path;

  uint32_t abi_major = 0;
  PluginFamily family = PluginFamily::kUnknown;

  std::string id;
  std::string name;
  std::string version;
  std::string min_plotjuggler_version;  ///< optional application-release expectation; advisory host policy
  std::string description;
  std::string category;
  std::vector<std::string> encoding;         ///< for message parsers (one or more)
  std::vector<std::string> file_extensions;  ///< for data sources
  std::vector<std::string> capabilities;     ///< optional capability tags
  /// Optional SDK contract floor; "" means undeclared. This is a hard host-side
  /// load gate, distinct from both the application release and the compile SDK.
  std::string min_sdk_required;
  /// Optional full-feature floor: the SDK release at which every capability
  /// this plugin uses is available ("" in manifests that do not declare it).
  /// min_sdk_required remains the FUNCTIONING floor; a host between the two
  /// runs the plugin with some optional features inactive. Informational, for
  /// host degradation display — never an admission criterion.
  std::string suggested_sdk_version;
};

/// Diagnostic for a candidate DSO that could not produce a valid descriptor.
struct PluginDiagnostic {
  std::filesystem::path path;
  std::string message;
};

/// Result of a directory scan: valid descriptors plus per-DSO diagnostics.
struct PluginScanResult {
  std::vector<PluginDescriptor> plugins;
  std::vector<PluginDiagnostic> diagnostics;
};

/// Decode a plugin's embedded manifest JSON into a descriptor, applying the
/// canonical validation both discovery paths share: `id`/`name`/`version` are
/// required non-empty strings, typed fields reject mismatched JSON types,
/// `min_sdk_required` is empty or one concrete SemVer 2.0.0 version, and a
/// message parser must declare a non-empty `encoding` array. `source_path` is
/// recorded as the descriptor's dso_path (for a DSO the file path; a host
/// registering a statically linked plugin passes a synthetic label instead);
/// error strings do not embed it — callers prefix their own source context.
[[nodiscard]] Expected<PluginDescriptor> decodeManifest(
    const std::filesystem::path& source_path, PluginFamily family, std::string_view manifest_json);

/// Inspect one DSO and return its embedded plugin descriptor.
[[nodiscard]] Expected<PluginDescriptor> inspectPluginDso(const std::filesystem::path& dso_path);

/// Inspect one DSO through an already-open @p handle originating at @p dso_path.
/// The supplied shared handle remains owned by the caller and is not reopened.
[[nodiscard]] Expected<PluginDescriptor> inspectPluginDso(
    const std::shared_ptr<void>& handle, const std::filesystem::path& dso_path);

/// Recursively scan a directory for platform plugin DSOs. Invalid candidates are
/// reported in diagnostics while discovery continues.
[[nodiscard]] Expected<PluginScanResult> scanPluginDsos(const std::filesystem::path& directory);

/// Human-readable name for a plugin family.
[[nodiscard]] std::string_view toString(PluginFamily family) noexcept;

namespace detail {

/// Return the plugin families whose getter symbols are defined by @p dso_path
/// itself. Missing getters are omitted; provenance and path-identity failures
/// are returned to the caller instead of being mistaken for absent families.
[[nodiscard]] Expected<std::vector<PluginFamily>> exportedPluginFamilies(
    const std::shared_ptr<void>& handle, const std::filesystem::path& dso_path);

}  // namespace detail

}  // namespace PJ
