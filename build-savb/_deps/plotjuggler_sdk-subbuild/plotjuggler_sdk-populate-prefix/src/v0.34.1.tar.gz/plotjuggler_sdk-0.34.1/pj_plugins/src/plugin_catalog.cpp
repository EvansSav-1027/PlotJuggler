// Copyright 2026 Davide Faconti
// SPDX-License-Identifier: Apache-2.0

#include "pj_plugins/host/plugin_catalog.hpp"

#include <fmt/format.h>

#include <algorithm>
#include <array>
#include <filesystem>
#include <memory>
#include <nlohmann/json.hpp>
#include <sstream>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>

#include "detail/library_loader.hpp"
#include "detail/vtable_validation.hpp"
#include "pj_base/data_source_protocol.h"
#include "pj_base/message_parser_protocol.h"
#include "pj_base/sdk/semver.hpp"
#include "pj_base/toolbox_protocol.h"
#include "pj_plugins/dialog_protocol.h"

namespace PJ {

namespace {

#if defined(_WIN32)
constexpr std::string_view kDsoSuffix = ".dll";
#elif defined(__APPLE__)
constexpr std::string_view kDsoSuffix = ".dylib";
#else
constexpr std::string_view kDsoSuffix = ".so";
#endif

struct ManifestCandidate {
  PluginFamily family = PluginFamily::kUnknown;
  std::string manifest_json;
};

bool hasDsoSuffix(const std::filesystem::path& path) {
  return path.extension().string() == kDsoSuffix;
}

bool nativeSymbolPresent(void* handle, const char* symbol) noexcept {
#if defined(_WIN32)
  return GetProcAddress(reinterpret_cast<HMODULE>(handle), symbol) != nullptr;
#else
  dlerror();
  void* resolved = dlsym(handle, symbol);
  return dlerror() == nullptr && resolved != nullptr;
#endif
}

// Direct-vtable families share the exact same probe sequence: resolve symbol,
// call entry, check protocol_version, check struct_size, read manifest_json.
// Only the family-specific types and constants vary.
template <typename Vtable, typename EntryFn>
Expected<ManifestCandidate> probeDirectVtable(
    void* handle, const detail::LibraryPathIdentity& origin, const char* symbol, const char* family_name,
    uint32_t expected_protocol, size_t min_vtable_size, PluginFamily family) {
  auto sym = detail::resolveSymbol(handle, symbol, origin);
  if (!sym) {
    return unexpected(sym.error());
  }
  const Vtable* vt = reinterpret_cast<EntryFn>(*sym)();
  if (vt == nullptr) {
    return unexpected(fmt::format("{} returned null", symbol));
  }
  if (vt->protocol_version != expected_protocol) {
    return unexpected(fmt::format("{} protocol version mismatch", family_name));
  }
  if (vt->struct_size < min_vtable_size) {
    return unexpected(fmt::format("{} vtable smaller than v4.0 baseline", family_name));
  }
  if (auto status = detail::validateRequiredSlots(vt); !status) {
    return unexpected(status.error());
  }
  return ManifestCandidate{family, vt->manifest_json == nullptr ? "" : vt->manifest_json};
}

Expected<ManifestCandidate> tryDataSource(void* handle, const detail::LibraryPathIdentity& origin) {
  return probeDirectVtable<PJ_data_source_vtable_t, PJ_get_data_source_vtable_fn>(
      handle, origin, "PJ_get_data_source_vtable", "DataSource", PJ_DATA_SOURCE_PROTOCOL_VERSION,
      PJ_DATA_SOURCE_MIN_VTABLE_SIZE, PluginFamily::kDataSource);
}

Expected<ManifestCandidate> tryMessageParser(void* handle, const detail::LibraryPathIdentity& origin) {
  return probeDirectVtable<PJ_message_parser_vtable_t, PJ_get_message_parser_vtable_fn>(
      handle, origin, "PJ_get_message_parser_vtable", "MessageParser", PJ_MESSAGE_PARSER_PROTOCOL_VERSION,
      PJ_MESSAGE_PARSER_MIN_VTABLE_SIZE, PluginFamily::kMessageParser);
}

Expected<ManifestCandidate> tryToolbox(void* handle, const detail::LibraryPathIdentity& origin) {
  return probeDirectVtable<PJ_toolbox_vtable_t, PJ_get_toolbox_vtable_fn>(
      handle, origin, "PJ_get_toolbox_vtable", "Toolbox", PJ_TOOLBOX_PLUGIN_PROTOCOL_VERSION,
      PJ_TOOLBOX_MIN_VTABLE_SIZE, PluginFamily::kToolbox);
}

Expected<ManifestCandidate> tryDialog(void* handle, const detail::LibraryPathIdentity& origin) {
  auto sym = detail::resolveSymbol(handle, "PJ_get_dialog_vtable", origin);
  if (!sym) {
    return unexpected(sym.error());
  }
  auto entry = reinterpret_cast<PJ_get_dialog_vtable_fn>(*sym);
  const PJ_dialog_vtable_t* vt = entry();
  if (vt == nullptr) {
    return unexpected("PJ_get_dialog_vtable returned null");
  }
  if (vt->protocol_version != PJ_DIALOG_PROTOCOL_VERSION) {
    return unexpected("Dialog protocol version mismatch");
  }
  if (vt->struct_size < PJ_DIALOG_MIN_VTABLE_SIZE) {
    return unexpected("Dialog vtable smaller than v4.0 baseline");
  }
  if (auto status = detail::validateRequiredSlots(vt); !status) {
    return unexpected(status.error());
  }
  if (PJ_HAS_TAIL_SLOT(PJ_dialog_vtable_t, vt, manifest_json)) {
    return ManifestCandidate{PluginFamily::kDialog, vt->manifest_json};
  }

  void* ctx = vt->create();
  if (ctx == nullptr) {
    return unexpected("PJ_dialog_vtable_t::create returned null");
  }
  const char* manifest = vt->get_manifest(ctx);
  std::string manifest_json = manifest == nullptr ? "" : manifest;
  vt->destroy(ctx);
  return ManifestCandidate{PluginFamily::kDialog, std::move(manifest_json)};
}

Expected<ManifestCandidate> findEmbeddedManifest(void* handle, const detail::LibraryPathIdentity& origin) {
  std::vector<std::string> errors;

  if (auto candidate = tryDataSource(handle, origin)) {
    return *candidate;
  } else {
    errors.push_back(fmt::format("data_source: {}", candidate.error()));
  }

  if (auto candidate = tryMessageParser(handle, origin)) {
    return *candidate;
  } else {
    errors.push_back(fmt::format("message_parser: {}", candidate.error()));
  }

  if (auto candidate = tryToolbox(handle, origin)) {
    return *candidate;
  } else {
    errors.push_back(fmt::format("toolbox: {}", candidate.error()));
  }

  if (auto candidate = tryDialog(handle, origin)) {
    return *candidate;
  } else {
    errors.push_back(fmt::format("dialog: {}", candidate.error()));
  }

  std::ostringstream out;
  out << "no supported plugin vtable found";
  for (const auto& error : errors) {
    out << "; " << error;
  }
  return unexpected(out.str());
}

Expected<std::vector<std::string>> readStringArray(const nlohmann::json& j, std::string_view key) {
  std::vector<std::string> values;
  const auto it = j.find(std::string(key));
  if (it == j.end()) {
    return values;
  }
  if (!it->is_array()) {
    return unexpected(fmt::format("plugin embedded manifest key must be an array of strings: {}", key));
  }
  for (const auto& value : *it) {
    if (!value.is_string()) {
      return unexpected(fmt::format("plugin embedded manifest key contains a non-string value: {}", key));
    }
    values.push_back(value.get<std::string>());
  }
  return values;
}

}  // namespace

Expected<PluginDescriptor> decodeManifest(
    const std::filesystem::path& source_path, PluginFamily family, std::string_view manifest_json) {
  if (manifest_json.empty()) {
    return unexpected("plugin embedded manifest is empty");
  }

  nlohmann::json j;
  try {
    j = nlohmann::json::parse(manifest_json);
  } catch (const nlohmann::json::exception& e) {
    return unexpected(fmt::format("plugin embedded manifest is invalid JSON: {}", e.what()));
  }

  if (!j.is_object()) {
    return unexpected("plugin embedded manifest must be a JSON object");
  }

  auto required_string = [&](std::string_view key) -> Expected<std::string> {
    const auto it = j.find(std::string(key));
    if (it == j.end() || !it->is_string() || it->get<std::string>().empty()) {
      return unexpected(fmt::format("plugin embedded manifest missing required string key: {}", key));
    }
    return it->get<std::string>();
  };
  auto optional_string = [&](std::string_view key) -> Expected<std::string> {
    const auto it = j.find(std::string(key));
    if (it == j.end()) {
      return std::string{};
    }
    if (!it->is_string()) {
      return unexpected(fmt::format("plugin embedded manifest key must be a string: {}", key));
    }
    return it->get<std::string>();
  };

  PluginDescriptor d;
  d.dso_path = source_path;
  d.abi_major = PJ_ABI_VERSION;
  d.family = family;

  auto id = required_string("id");
  if (!id) {
    return unexpected(id.error());
  }
  auto name = required_string("name");
  if (!name) {
    return unexpected(name.error());
  }
  auto version = required_string("version");
  if (!version) {
    return unexpected(version.error());
  }

  d.id = *id;
  d.name = *name;
  d.version = *version;

  auto description = optional_string("description");
  if (!description) {
    return unexpected(description.error());
  }
  auto category = optional_string("category");
  if (!category) {
    return unexpected(category.error());
  }
  auto min_plotjuggler_version = optional_string("min_plotjuggler_version");
  if (!min_plotjuggler_version) {
    return unexpected(min_plotjuggler_version.error());
  }
  auto suggested_sdk_version = optional_string("suggested_sdk_version");
  if (!suggested_sdk_version) {
    return unexpected(suggested_sdk_version.error());
  }
  auto min_sdk_required = optional_string("min_sdk_required");
  if (!min_sdk_required) {
    return unexpected(min_sdk_required.error());
  }
  if (!min_sdk_required->empty()) {
    auto parsed_min_sdk = SemVer::parse(*min_sdk_required);
    if (!parsed_min_sdk) {
      return unexpected(
          fmt::format(
              "plugin embedded manifest key min_sdk_required has invalid semantic version value \"{}\": {}",
              *min_sdk_required, parsed_min_sdk.error()));
    }
  }
  auto file_extensions = readStringArray(j, "file_extensions");
  if (!file_extensions) {
    return unexpected(file_extensions.error());
  }
  auto capabilities = readStringArray(j, "capabilities");
  if (!capabilities) {
    return unexpected(capabilities.error());
  }

  d.description = *description;
  d.category = *category;
  d.min_plotjuggler_version = *min_plotjuggler_version;
  d.min_sdk_required = *min_sdk_required;
  d.suggested_sdk_version = *suggested_sdk_version;
  d.file_extensions = *file_extensions;
  d.capabilities = *capabilities;

  auto encoding = readStringArray(j, "encoding");
  if (!encoding) {
    return unexpected(encoding.error());
  }
  if (family == PluginFamily::kMessageParser && encoding->empty()) {
    return unexpected("plugin embedded manifest missing required encoding array");
  }
  d.encoding = std::move(*encoding);

  return d;
}

std::string_view toString(PluginFamily family) noexcept {
  switch (family) {
    case PluginFamily::kDataSource:
      return "data_source";
    case PluginFamily::kMessageParser:
      return "message_parser";
    case PluginFamily::kToolbox:
      return "toolbox";
    case PluginFamily::kDialog:
      return "dialog";
    case PluginFamily::kUnknown:
      return "unknown";
  }
  return "unknown";
}

Expected<PluginDescriptor> inspectPluginDso(const std::filesystem::path& dso_path) {
  if (!hasDsoSuffix(dso_path)) {
    return unexpected(fmt::format("not a platform plugin DSO: {}", dso_path.string()));
  }

  detail::LibraryPathIdentity recorded_path;
  auto raw_handle = detail::loadLibraryHandle(dso_path, &recorded_path);
  if (!raw_handle) {
    return unexpected(fmt::format("{}: {}", dso_path.string(), raw_handle.error()));
  }
  return inspectPluginDso(detail::adoptLibraryHandle(*raw_handle), recorded_path.load_path);
}

Expected<PluginDescriptor> inspectPluginDso(
    const std::shared_ptr<void>& handle, const std::filesystem::path& dso_path) {
  if (!hasDsoSuffix(dso_path)) {
    return unexpected(fmt::format("not a platform plugin DSO: {}", dso_path.string()));
  }
  auto with_path = [&](const std::string& error) { return fmt::format("{}: {}", dso_path.string(), error); };
  if (handle == nullptr) {
    return unexpected(with_path("library not loaded"));
  }

  auto recorded_path = detail::recordLibraryPathIdentity(dso_path);
  if (!recorded_path) {
    return unexpected(with_path(recorded_path.error()));
  }

  if (auto abi = detail::checkPluginAbiVersion(handle.get(), *recorded_path); !abi) {
    return unexpected(with_path(abi.error()));
  }

  auto candidate = findEmbeddedManifest(handle.get(), *recorded_path);
  if (!candidate) {
    return unexpected(with_path(candidate.error()));
  }

  auto descriptor = decodeManifest(dso_path, candidate->family, candidate->manifest_json);
  if (!descriptor) {
    return unexpected(with_path(descriptor.error()));
  }
  return *descriptor;
}

namespace detail {

Expected<std::vector<PluginFamily>> exportedPluginFamilies(
    const std::shared_ptr<void>& handle, const std::filesystem::path& dso_path) {
  std::vector<PluginFamily> families;
  if (handle == nullptr) {
    return unexpected("library not loaded");
  }
  auto recorded_path = recordLibraryPathIdentity(dso_path);
  if (!recorded_path) {
    return unexpected(recorded_path.error());
  }

  auto append_if_owned = [&](const char* symbol, PluginFamily family) -> Expected<void> {
    if (!nativeSymbolPresent(handle.get(), symbol)) {
      return {};
    }
    auto resolved = resolveSymbol(handle.get(), symbol, *recorded_path);
    if (!resolved) {
      return unexpected(resolved.error());
    }
    families.push_back(family);
    return {};
  };
  for (const auto& [symbol, family] : std::array<std::pair<const char*, PluginFamily>, 4>{
           std::pair{"PJ_get_data_source_vtable", PluginFamily::kDataSource},
           {"PJ_get_message_parser_vtable", PluginFamily::kMessageParser},
           {"PJ_get_toolbox_vtable", PluginFamily::kToolbox},
           {"PJ_get_dialog_vtable", PluginFamily::kDialog},
       }) {
    if (auto status = append_if_owned(symbol, family); !status) {
      return unexpected(status.error());
    }
  }
  return families;
}

}  // namespace detail

Expected<PluginScanResult> scanPluginDsos(const std::filesystem::path& directory) {
  std::error_code ec;
  if (!std::filesystem::exists(directory, ec)) {
    return unexpected(fmt::format("plugin directory not found: {}", directory.string()));
  }
  if (!std::filesystem::is_directory(directory, ec)) {
    return unexpected(fmt::format("plugin path is not a directory: {}", directory.string()));
  }

  PluginScanResult result;
  // Use the increment-with-error-code overload so a single inaccessible subtree
  // (e.g. one extension dir owned by another user) doesn't terminate the entire
  // scan and silently hide every later extension from the marketplace.
  std::filesystem::recursive_directory_iterator it(directory, ec);
  if (ec) {
    result.diagnostics.push_back({directory, fmt::format("directory iteration failed: {}", ec.message())});
    return result;
  }
  const std::filesystem::recursive_directory_iterator end;
  while (it != end) {
    const auto entry = *it;
    std::error_code entry_ec;
    const bool is_file = entry.is_regular_file(entry_ec);
    if (!entry_ec && is_file && hasDsoSuffix(entry.path())) {
      auto descriptor = inspectPluginDso(entry.path());
      if (descriptor) {
        result.plugins.push_back(std::move(*descriptor));
      } else {
        result.diagnostics.push_back({entry.path(), descriptor.error()});
      }
    } else if (entry_ec) {
      result.diagnostics.push_back({entry.path(), fmt::format("stat failed: {}", entry_ec.message())});
    }

    std::error_code inc_ec;
    it.increment(inc_ec);
    if (inc_ec) {
      result.diagnostics.push_back({entry.path(), fmt::format("directory iteration failed: {}", inc_ec.message())});
      // Skip the unreadable subtree but continue with the rest of the scan.
      it.pop();
    }
  }

  std::sort(result.plugins.begin(), result.plugins.end(), [](const PluginDescriptor& a, const PluginDescriptor& b) {
    return a.dso_path < b.dso_path;
  });
  std::sort(
      result.diagnostics.begin(), result.diagnostics.end(),
      [](const PluginDiagnostic& a, const PluginDiagnostic& b) { return a.path < b.path; });

  return result;
}

}  // namespace PJ
